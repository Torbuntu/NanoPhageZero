#include <Pokitto.h>
static const uint8_t B_UP = 1 << UPBIT;
static const uint8_t B_DOWN = 1 << DOWNBIT;
static const uint8_t B_LEFT = 1 << LEFTBIT;
static const uint8_t B_RIGHT = 1 << RIGHTBIT;
static const uint8_t B_A = 1 << ABIT;
static const uint8_t B_B = 1 << BBIT;
static const uint8_t B_C = 1 << CBIT;