#pragma once

struct UIVariants{
    static constexpr unsigned standard = 0;
    static constexpr unsigned blackBG = 8;
    static constexpr unsigned halfBlackBG = 16;
    static constexpr unsigned red = 24;
    static constexpr unsigned green = 32;
};